import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css'; 

import MovieDetails from './Commponent/MovieDetails';
import Home from './Commponent/Home';
import Header from './Commponent/Header';
import Popular from './Commponent/Popular';
import Upcoming from './Commponent/Upcoming';
import Search from './Search';


const App = () => {
  const Erro = () => "Error";
  return (
    <>
      <Router>
        <Header />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="popular" element={<Popular />} />
          <Route path="movie/:id" element={<MovieDetails />} />
          <Route path="search" element={<Search />} />
          <Route path="upcoming" element={<Upcoming />} />
        
          <Route path="*" element={<Erro />} />
        </Routes>
      </Router>
    </>
  );
};

export default App;
