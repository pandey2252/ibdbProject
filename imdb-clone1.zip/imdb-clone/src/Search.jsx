import React, { useState } from 'react';
import './search.css';
import Cards from './Commponent/Card';

const API_KEY = '27bc402a9685cee61ad92333174299fe';

const Search = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);

  const handleInputChange = (event) => {
    setQuery(event.target.value);
  };

  const handleSearch = async () => {
    const searchEndpoint = `https://api.themoviedb.org/3/search/movie?api_key=${API_KEY}&query=${query}`;

    try {
      const response = await fetch(searchEndpoint);
      const data = await response.json();
      setResults(data.results);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <div className="search-box">
      <input
        type="text"
        placeholder="Search for movies..."
        value={query}
        onChange={handleInputChange}
      />
      <button onClick={handleSearch}>Search</button>

      <Cards movies={results} />
    </div>
  );
};

export default Search;
