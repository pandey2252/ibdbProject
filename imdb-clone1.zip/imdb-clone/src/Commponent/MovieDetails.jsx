import React, { useEffect, useState } from 'react';
import './MovieDetails.css';
import { useParams } from 'react-router-dom';

const MovieDetails = () => {
  const [currentMovieDetail, setMovie] = useState();
  const { id } = useParams();

  useEffect(() => {
    getData();
    window.scrollTo(0, 0);
  }, [id]);

  const getData = () => {
    fetch(`https://api.themoviedb.org/3/movie/${id}?api_key=4e44d9029b1270a757cddc766a1bcb63&language=en-US`)
      .then((res) => res.json())
      .then((data) => setMovie(data));
  };

  if (!currentMovieDetail) {
    return <div>Loading...</div>;
  }

  return (
    <div className="movie-details">
      <div className="movie-details__intro">
        <img
          className="movie-details__backdrop"
          src={`https://image.tmdb.org/t/p/original${currentMovieDetail.backdrop_path}`}
          alt="Backdrop"
        />
      </div>

      <div className="movie-details__content">
        <h1 className="movie-details__title">{currentMovieDetail.title}</h1>
        <p className="movie-details__overview">{currentMovieDetail.overview}</p>

     
        <div className="movie-details__details">
          <p>Release Date: {currentMovieDetail.release_date}</p>
          <p>Runtime: {currentMovieDetail.runtime} mins</p>
        
        </div>
      </div>
    </div>
  );
};

export default MovieDetails;
