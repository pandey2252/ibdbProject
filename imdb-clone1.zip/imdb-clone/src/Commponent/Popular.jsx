import React, { useState, useEffect } from 'react';
import Card from "./Card"
import "./Card.css"

const Popular = () => {
  const [PopularMovies, setPopularMovies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const API_KEY = '27bc402a9685cee61ad92333174299fe';
    const apiUrl = `https://api.themoviedb.org/3/movie/popular?api_key=${API_KEY}`;

    fetch(apiUrl)
      .then((res) => res.json())
      .then((data) => {
        setPopularMovies(data.results);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
        setLoading(false);
      });
  }, []);

  return (
    <>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div className="cards-container">
          {PopularMovies.map((movie) => (
            <Card  movie={movie} />
          ))}
        </div>
      )}
    </>
  );
}

export default Popular;
