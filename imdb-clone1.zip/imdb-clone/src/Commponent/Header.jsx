import React from 'react';
import { Link } from 'react-router-dom';
import "./Header.css"

const Header = () => {
  return (
    <nav className="nav">
      <div className="container">
        <h1 className="logo">
          <Link to="/">
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/IMDB_Logo_2016.svg/575px-IMDB_Logo_2016.svg.png" alt="" className='icon' />
          </Link>
        </h1>
        <ul>
          <li><Link to="/">Home</Link></li>
          <li><Link to="/popular">Popular</Link></li>
          <li><Link to="/upcoming">Upcoming</Link></li>
          {/* <li><Link to="/search">Search</Link></li> */}
       
        </ul>
      </div>
     
    </nav>
  );
};

export default Header;
